================================================================
  RAPPORT LATEX — PRÉDICTION DES PRIX IMMOBILIERS (CRISP-DM)
================================================================

POINT D'ENTRÉE
--------------
  main.tex  →  Compiler ce fichier uniquement

COMMANDE DE COMPILATION
------------------------
  pdflatex main.tex
  pdflatex main.tex   (2e passe pour la table des matières)

  Ou avec latexmk (recommandé) :
  latexmk -pdf main.tex

STRUCTURE DES FICHIERS
-----------------------

  main.tex                        Point d'entrée principal

  config/
    packages.tex                  Tous les \usepackage{...}
    mise_en_page.tex              Géométrie, marges, interligne
    couleurs.tex                  Palette de couleurs (definecolor)
    styles_titres.tex             Mise en forme chapter/section
    entetes_pieds.tex             En-têtes et pieds de page (fancyhdr)
    code_listings.tex             Style des blocs de code (lstset)
    boites.tex                    Boîtes infobox / successbox / warnbox
    hyperref_config.tex           Configuration des hyperliens PDF
    page_titre.tex                Page de titre du rapport

  chapitres/
    00_resume.tex                 Résumé (abstract)
    00_introduction.tex           Introduction générale
    01_business_understanding.tex Phase 1 CRISP-DM
    02_data_understanding.tex     Phase 2 CRISP-DM
    03_data_preparation.tex       Phase 3 CRISP-DM
    04_modeling.tex               Phase 4 CRISP-DM
    05_evaluation.tex             Phase 5 CRISP-DM
    06_deployment.tex             Phase 6 CRISP-DM
    07_conclusion.tex             Conclusion et perspectives
    08_bibliographie.tex          Références bibliographiques

  annexes/
    A_structure_projet.tex        Arborescence du projet
    B_installation.tex            Guide d'installation
    C_metriques.tex               Tableau des métriques détaillées

  img/                            Déposez vos figures ici
    (ex: eda_distributions.png, correlation_matrix.png, ...)

PERSONNALISATION
-----------------
  - Remplacer [val] par vos résultats réels dans les tableaux
  - Décommenter les \includegraphics et supprimer les \fbox
  - Renseigner vos informations dans config/page_titre.tex
================================================================
